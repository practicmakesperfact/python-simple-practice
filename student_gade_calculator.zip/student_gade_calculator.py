print("Student Grade Calculator \n\n")
while True:
   totalGrade=0
   
   name=input("Please Enter Your name: ")
   courses_number=int(input("how many courses do you take:"))
   x=0
   while x<courses_number:
        grade=float(input(f"please Enter Grade {x+1}(100%): "))
        totalGrade+=grade
        x+=1
   average=(totalGrade/courses_number)
   if average <50:
        print(f"{name}, your score is:{average:.2f},you fail exams please read more.")
   else:
        print(f"{name},your score is:{average:.2f}, passed!")
   inputValue=input("Do you want to add other student(y/n)?")
   if inputValue!='y'and inputValue!='Y':
       break



#  Ezedin Gashaw ID 4348/14
# Bizualem Abebe  ID  2057/14
# Hamanot Asmare   ID 2594/14